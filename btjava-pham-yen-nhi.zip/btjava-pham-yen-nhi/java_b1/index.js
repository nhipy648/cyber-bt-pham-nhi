// alert("hello JS");
console.log("hello JS BC");